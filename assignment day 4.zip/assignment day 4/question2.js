const student ={ 
    name: "helsinki",
    age: "24",
    project: {diceGame: "two player dice game using javascript"}
}

console.log(student.name);
console.log(student.age);
console.log(student.project.diceGame);
