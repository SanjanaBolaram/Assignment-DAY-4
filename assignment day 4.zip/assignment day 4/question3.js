let shoppinglist= ['fruits','veggies', 'milk','curd'];
let shoppingBasket =shoppinglist.concat(['biscuits','rice','wheat']);
console.log(shoppingBasket);